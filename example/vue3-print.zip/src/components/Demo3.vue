<template>
  <div style="margin-top: 20px;">多页模版</div>
  <p>{{ url }}</p>
  <button @click="print">生 成3</button>&nbsp;&nbsp;&nbsp;
  <button :readonly="url ? true : false" @click="openPdf">打 开3</button>
</template>
<script setup lang="ts">
import { ref, reactive } from "vue";
import printTemplate from "print-template";
const url = ref("");
const wait = ref(false);
const info = reactive({
  num: 10,
  code: "1111",
  name: "张三",
});
const template = new printTemplate();

template.push({
  name: "expressDelivery3",
  size: [76, 136],
  multiPage: true,
  // 关联 模板 ： 打印时验证存不存在模板 如果为空或模板为空 不生成pdf页
  linkTemplate: ['expressDelivery1','expressDelivery2'],
  // 分页方式  传入打印每行的数据 分配模板打印数据
  // 返回需要打印的信息
  // - 返回 null 继续打印当前模版 
  // - 返回 [] 空数组什么也不打印
  // - 返回 [{name:'模版名称',data:{打印对象}},{name:'模版名称',data:{打印对象}] 打印多页信息
  pageMode: function (data:any) {
    if (data.id %2 >0) {
      return [{ name: 'expressDelivery1', data:{name: '模版1 ' + data.name} }, { name: 'expressDelivery2', data: { code: data.code ,name: '模版2 ' + data.name} }]
    }else{
      // this 是当前push 的对象
      // this.name 
      return [{ name: this.name, data:{ code : data.code , name:'当前模版 '+data.name} }]
    }
  },
  fixed: [
    {
      type: "text",
      fontSize: 3.8,
      fontWeight: 700,
      x: 66,
      y: 2,
      default: "货到\n付款",
    },
    {
      type: "qrcode",
      x: 25,
      y: 79,
      width: 25,
      default: "开发不易，记得start奥1111111111",
    },
  ],

  data: {
    name: { type: "text", x: 8, y: 45, fontSize: 3.5 },
    code: {
      type: "barcode",
      x: 7,
      y: 13,
      format: "CODE128A",
      width: 4,
      margin: 0,
      fontSize: 3.3,
      fontOptions: "bold",
      displayValue: true,
      height: 13,
    },
  },
});

function openPdf() {
  if (url.value) {
    let link = document.createElement("a");
    link.href = url.value;
    link.target = "_blank";
    link.click();
    console.log(url.value);
  } else {
    alert("请先点击生成按钮");
  }

  // window.open(this.url, '_blank');
}
function print() {
  if(wait.value){
    alert('正在生成中,请等待')
    return
  }
  wait.value = true
  let data = [];
  url.value = "";
  // 生成num条数据
  for (let index = 0; index < info.num; index++) {
    data.push({
      id: index + 1, // 根据Id 判断是否分页 
      code: info.code + (index + 1),
      name: info.name + (index + 1),
    });
  }
  console.log(data);

  //  getPrintData 和  print 不能同时使用
  // template.getPrintData("expressDelivery2", data).then((printData: any) => {
  //  console.log(printData);
  // }).finally(()=>{
  //  wait.value = false
  //});

  //生成pdf文件
  template.print("expressDelivery3", data).then((pdf: any) => {
    if (pdf) {
      url.value = pdf.output("bloburi", { filename: "打印文件" });
    } else {
    }
  }).finally(()=>{
    wait.value = false
  });
}
</script>
