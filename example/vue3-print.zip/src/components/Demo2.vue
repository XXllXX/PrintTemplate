<template>
  <div style="margin-top: 20px;">使用背景图片</div>
  <p>{{ url }}</p>
  <button @click="print">生 成2</button>&nbsp;&nbsp;&nbsp;
  <button :readonly="url ? true : false" @click="openPdf">打 开2</button>
</template>
<script setup lang="ts">
import { ref, reactive } from "vue";
import printTemplate from "print-template";
import bg from "../assets/bg.png";
const url = ref("");
const wait = ref(false);
const info = reactive({
  num: 20,
  code: "1111",
  name: "张三",
});
const template = new printTemplate();

template.push({
  name: "expressDelivery2",
  size: [76, 136],
  multiPage: false,
  fixed: [
    // 背景图片
    { type: "image", default: bg, width: 76, height: 136 },
    {
      type: "text",
      fontSize: 3.8,
      fontWeight: 700,
      x: 66,
      y: 2,
      default: "货到\n付款",
    },
    {
      type: "qrcode",
      x: 25,
      y: 79,
      width: 25,
      default: "开发不易，记得start奥1111111111",
    },
  ],

  data: {
    name: { type: "text", x: 8, y: 45, fontSize: 3.5 },
    code: {
      type: "barcode",
      x: 7,
      y: 13,
      format: "CODE128A",
      width: 4,
      margin: 0,
      fontSize: 3.3,
      fontOptions: "bold",
      displayValue: true,
      height: 13,
    },
  },
});

function openPdf() {
  if (url.value) {
    let link = document.createElement("a");
    link.href = url.value;
    link.target = "_blank";
    link.click();
    console.log(url.value);
  } else {
    alert("请先点击生成按钮");
  }

  // window.open(this.url, '_blank');
}
function print() {
  if(wait.value){
    alert('正在生成中,请等待')
    return
  }
  wait.value = true
  let data = [];
  url.value = "";
  // 生成num条数据
  for (let index = 0; index < info.num; index++) {
    data.push({
      code: info.code + (index + 1),
      name: info.name + (index + 1),
    });
  }
  console.log(data);

  //  getPrintData 和  print 不能同时使用
  // template.getPrintData("expressDelivery2", data).then((printData: any) => {
  //  console.log(printData);
  // }).finally(()=>{
  //  wait.value = false
  //});

  //生成pdf文件
  template.print("expressDelivery2", data).then((pdf: any) => {
    if (pdf) {
      url.value = pdf.output("bloburi", { filename: "打印文件" });
    } else {
    }
  }).finally(()=>{
    wait.value = false
  });
}
</script>
