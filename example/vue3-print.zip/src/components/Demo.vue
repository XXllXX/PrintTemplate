<template>
  <p>{{ url }}</p>
  <button @click="print">生 成1</button>&nbsp;&nbsp;&nbsp;
  <button :readonly="url ? true : false" @click="openPdf">打 开1</button>
</template>
<script setup lang="ts">
import { ref, reactive } from "vue";
import printTemplate from "print-template";

const url = ref("");
const wait = ref(false);
const info = reactive({
  num: 1,
  code: "1111",
  name: "张三",
});
const template = new printTemplate();
template.push({
  name: "expressDelivery1",
  size: [76, 136],
  dpi:300,
  multiPage: true,
  linkTemplate: ["expressDelivery1"],
  fixed: [
    { type: "line", x: 2, y: 12, length: 72  , width:0.3, color:'red'},
    { type: "line", x: 2, y: 12, orientation: "p", length: 116 ,width:0.3,color:'blue' },
    { type: "line", x: 74, y: 12, orientation: "p", length: 116 ,width:0.3, color:'#771caa'},
    { type: "line", x: 2, y: 27, length: 72 , width:0.3,color:'yellow'},
    { type: "line", x: 2, y: 35, length: 72 , color:'#green'},
    { type: "line", x: 2, y: 41, length: 52 },
    { type: "line", x: 54, y: 35, orientation: "p", length: 32 },
    { type: "line", x: 54, y: 49, length: 20 },
    { type: "line", x: 2, y: 59, length: 72 },
    { type: "line", x: 2, y: 67, length: 72 },
    { type: "line", x: 2, y: 77, length: 72 },
    { type: "line", x: 2, y: 110, length: 72 },
    { type: "line", x: 2, y: 128, length: 72 },
    {
      type: "text",
      fontSize: 3.8,
      fontWeight: 700,
      x: 66,
      y: 2,
      default: "货到\n付款",
      color:'red'
    },
    {
      type: "qrcode",
      x: 25,
      y: 79,
      width: 25,
      default: "开发不易，记得start奥",
    },
  ],

  data: {
    name: { type: "text", x: 8, y: 45, fontSize: 3.5 ,color:'red' },
    code: {
      type: "barcode",
      x: 7,
      y: 13,
      format: "CODE128A",
      width: 5,
      margin: 0,
      fontSize: 3.3,
      fontOptions: "bold",
      displayValue: true,
      height: 13,
    },
  },
});

function openPdf() {
  if (url.value) {
    let link = document.createElement("a");
    link.href = url.value;
    link.target = "_blank";
    link.click();
    console.log(url.value);
  } else {
    alert("请先点击生成按钮");
  }

  // window.open(this.url, '_blank');
}
function print() {
  if(wait.value){
    alert('正在生成中,请等待')
    return
  }
  let data = [];
  url.value = "";
  // 生成num条数据
  for (let index = 0; index < info.num; index++) {
    data.push({
      code: info.code + (index + 1),
      name: info.name + (index + 1),
    });
  }
  console.log(data)

  //  getPrintData 和  print 不能同时使用
  // template.getPrintData("expressDelivery1", data).then((printData: any) => {
  // console.log(printData);
  // }).finally(()=>{
  //  wait.value = false
  //});;

  //生成pdf文件
  template.print("expressDelivery1", data).then((pdf: any) => {
    if (pdf) {
      url.value = pdf.output("bloburi", { filename: "打印文件" });
    } else {
    }
  }).finally(()=>{
    wait.value = false
  });;
}
</script>