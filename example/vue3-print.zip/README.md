# Vue3 print-template Demo

## 安装
```sh
npm install print-template
# 或
pnpm install  print-template
```
## 使用
[Demo1](./src/components/Demo.vue)

[Demo2](./src/components/Demo2.vue)